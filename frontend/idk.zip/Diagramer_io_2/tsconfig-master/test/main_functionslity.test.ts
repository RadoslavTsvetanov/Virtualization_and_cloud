
import supertest  from 'supertest'
const serverUrl = 'http://localhost:3000'; // Adjust the URL based on your server configuration
//! if tests fail first check if backend is running
