"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const serverUrl = 'http://localhost:3000'; // Adjust the URL based on your server configuration
//! if tests fail first check if backend is running
