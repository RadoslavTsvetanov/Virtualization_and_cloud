Config for writing in node and ts
