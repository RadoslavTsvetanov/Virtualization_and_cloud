*Dependencies*
- ts installed globally
- ts-node installed globally
- nodemon to be installed


*How to use*
npm start -> "compiles" and runs index.ts
it only compiles thing in src folder (include: [src....])